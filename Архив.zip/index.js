import './js/scheme.js'
import './js/slider.js'
import './js/tooltips.js'
import './js/animation.js'


